If you are going to use the Yelp dataset, please cite:

    @InProceedings{xu2016cached,
      author = {Xu, Jiacheng and Chen, Danlu and Qiu, Xipeng and Huang, Xuanjing},
      year = {2016},
      title = {{Cached Long Short-Term Memory Neural Networks for Document-Level Sentiment Classification}},
      journal = {Proceedings of the 2016 Conference on Empirical Methods in Natural Language Processing},
      publisher = {Proceedings of the 2016 Conference on Empirical Methods in Natural Language Processing}
    }